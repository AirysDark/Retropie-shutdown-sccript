#!/bin/bash
set -euo pipefail

INSTALL_DIR="/opt/retroflag-picase"
SERVICE_FILE="/etc/systemd/system/retroflag-picase.service"

echo "[1/5] Installing dependencies (python3, RPi.GPIO)..."
apt-get update -y
apt-get install -y python3 python3-rpi.gpio

echo "[2/5] Installing files to ${INSTALL_DIR} ..."
mkdir -p "${INSTALL_DIR}"
install -m 0755 opt/service.py "${INSTALL_DIR}/service.py"
install -m 0755 opt/shutdown.retropie "${INSTALL_DIR}/shutdown.retropie"

echo "[3/5] Installing systemd service ..."
install -m 0644 etc/retroflag-picase.service "${SERVICE_FILE}"
systemctl daemon-reload

echo "[4/5] Enabling and starting service ..."
systemctl enable retroflag-picase.service
systemctl restart retroflag-picase.service

echo "[5/5] Done. Verify status with: systemctl status retroflag-picase.service"
echo "If the LED or buttons are inverted, you may need to edit pins in ${INSTALL_DIR}/service.py (BOARD pins 3/5/7/8)."
