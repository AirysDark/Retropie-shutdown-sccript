#!/usr/bin/env python3
# RetroFlag Pi Case safe shutdown script (DietPi-optimized)
# Compatible with Python 3.
# Patched: use absolute paths, correct shutdown script name, and python3 shebang.

import os
import signal
import sys
import threading
import time

try:
    import RPi.GPIO
except ImportError as e:
    sys.stderr.write("ERROR: RPi.GPIO not installed. Install with: sudo apt install -y python3-rpi.gpio\n")
    raise

# Resolve script directory for calling companion shell script
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

# GPIO assignments are BOARD numbers to match original wiring
POWER_SWITCH_PIN = 5   # power switch input
RESET_SWITCH_PIN = 3   # reset switch input
POWER_PIN = 7          # power enable output
LED_PIN = 8            # LED enable output
POLL_INTERVAL = 0.1    # seconds between polling of inputs

# pin number -> command
SWITCH_COMMAND_MAP = {
    POWER_SWITCH_PIN: os.path.join(SCRIPT_DIR, 'shutdown.retropie') + ' power',
    RESET_SWITCH_PIN: os.path.join(SCRIPT_DIR, 'shutdown.retropie') + ' reset',
}

def main():
    """Program entry point."""
    init_gpio()
    led_blinker = Blinker(LED_PIN)
    led_blinker.start()

    # create a trap to set LED solid before process exits
    def handle_signal(signum, frame):
        led_blinker.stop()
        led_blinker.join()
        sys.exit(0)
    signal.signal(signal.SIGINT, handle_signal)   # user exit (for testing)
    signal.signal(signal.SIGTERM, handle_signal)  # system exit (for shutdown)

    # run command for each switch press
    while True:
        pin = wait_for_press([POWER_SWITCH_PIN, RESET_SWITCH_PIN])
        # blink LED while command runs
        led_blinker.blink()
        os.system(SWITCH_COMMAND_MAP[pin])  # deliberately simple
        led_blinker.solid()

def init_gpio():
    """Set pin directions and pull-ups/pull-downs."""
    RPi.GPIO.setmode(RPi.GPIO.BOARD)
    RPi.GPIO.setwarnings(False)

    RPi.GPIO.setup(POWER_SWITCH_PIN, RPi.GPIO.IN, pull_up_down=RPi.GPIO.PUD_UP)
    RPi.GPIO.setup(RESET_SWITCH_PIN, RPi.GPIO.IN, pull_up_down=RPi.GPIO.PUD_UP)
    RPi.GPIO.setup(POWER_PIN, RPi.GPIO.OUT, initial=RPi.GPIO.HIGH)

def wait_for_press(pins):
    """Wait for a falling edge on one of pins and return pin number."""
    prev_states = [RPi.GPIO.input(pin) for pin in pins]
    while True:
        states = []

        for index, pin in enumerate(pins):
            prev_state = prev_states[index]
            state = RPi.GPIO.input(pin)

            # detect falling edge
            if prev_state == RPi.GPIO.HIGH and state == RPi.GPIO.LOW:
                return pin

            states.append(state)

        # set previous state
        prev_states = states

        # wait a moment before polling again
        time.sleep(POLL_INTERVAL)

class Blinker(threading.Thread):
    """Blink an LED while a command is running."""
    DEFAULT_STATE = True
    BLINK_INTERVAL = 0.25

    def __init__(self, pin):
        super(Blinker, self).__init__()

        self._pin = pin
        self._blink_event = threading.Event()  # set to enable blinking
        self._stop_event = threading.Event()   # set to stop thread

        RPi.GPIO.setup(pin, RPi.GPIO.OUT)

    def run(self):
        """Implementation of threading.Thread.run()."""
        state = self.DEFAULT_STATE
        while not self._stop_event.is_set():
            # blinking state
            if self._blink_event.is_set():
                state = not state
            # solid state
            else:
                state = self.DEFAULT_STATE

            RPi.GPIO.output(self._pin, state)
            self._stop_event.wait(self.BLINK_INTERVAL)

        # return to default state
        RPi.GPIO.output(self._pin, self.DEFAULT_STATE)

    def stop(self):
        """Stop thread."""
        self._stop_event.set()

    def blink(self):
        """Start blinking."""
        self._blink_event.set()

    def solid(self):
        """Stop blinking."""
        self._blink_event.clear()


if __name__ == '__main__':
    main()
