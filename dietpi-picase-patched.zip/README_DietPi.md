# RetroFlag Pi Case – DietPi Patch

This patch makes the original RetroPie shutdown script work cleanly on **DietPi**.

### What changed
- Force **Python 3** (`#!/usr/bin/env python3`) and systemd to call `python3`.
- Use **absolute paths** for the helper script (no `./shutdown.sh` mismatch).
- Correct command mapping to `shutdown.retropie`.
- Simple DietPi installer and a clean **systemd** unit.

### Pins / Wiring
The script uses **BOARD** numbering:
- `POWER_SWITCH_PIN = 5`
- `RESET_SWITCH_PIN = 3`
- `POWER_PIN = 7`
- `LED_PIN = 8`

Adjust at `/opt/retroflag-picase/service.py` if your case is wired differently.

### Install (on DietPi)
```bash
# 1) unzip the archive
unzip dietpi-picase-patched.zip -d dietpi-picase-patched
cd dietpi-picase-patched

# 2) run installer as root
sudo ./dietpi_install.sh

# 3) check that it’s running
systemctl status retroflag-picase.service
```

### Uninstall
```bash
sudo systemctl disable --now retroflag-picase.service
sudo rm -f /etc/systemd/system/retroflag-picase.service
sudo rm -rf /opt/retroflag-picase
sudo systemctl daemon-reload
```

### Notes
- Ensure your user presses the physical **power** and **reset** buttons to test.
- If you don’t have EmulationStation/RetroArch on DietPi, the shutdown script still powers off safely; the `killall` lines are a no-op.
