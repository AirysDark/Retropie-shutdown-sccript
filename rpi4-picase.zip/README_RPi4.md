# RetroFlag Pi Case – RPi4 (Raspberry Pi OS) package

This package targets **Raspberry Pi 4** on Raspberry Pi OS (Bullseye/Bookworm) and RetroPie.

## Features
- Python 3 + systemd service (`retroflag-picase.service`)
- Absolute path call to `shutdown.retropie`
- BOARD pin numbers aligned with common RetroFlag wiring:
  - POWER switch: pin 5 (GPIO3)
  - RESET switch: pin 3 (GPIO2)
  - POWER enable: pin 7 (GPIO4)
  - LED: pin 8 (GPIO14)

> Adjust these in `/opt/retroflag-picase/service.py` if your case differs.

## Install
```bash
unzip rpi4-picase.zip -d rpi4-picase
cd rpi4-picase
sudo ./rpi4_install.sh
sudo systemctl status retroflag-picase.service
```

## Optional: overlays
Installer appends these to `/boot/config.txt` (or `/boot/firmware/config.txt` on Bookworm) if missing:
```
dtoverlay=gpio-shutdown,gpio_pin=3,active_low=1,gpio_pull=up
dtoverlay=gpio-poweroff,gpiopin=14,active_low=0
```
They provide hardware-level shutdown/poweroff support complementary to the script.

## Uninstall
```bash
sudo systemctl disable --now retroflag-picase.service
sudo rm -f /etc/systemd/system/retroflag-picase.service
sudo rm -rf /opt/retroflag-picase
sudo systemctl daemon-reload
```
