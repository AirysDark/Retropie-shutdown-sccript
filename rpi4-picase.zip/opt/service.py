#!/usr/bin/env python3
# RetroFlag Pi Case safe shutdown script (RPi4 / Raspberry Pi OS)
# Uses Python 3 and systemd. BOARD pin numbering.

import os, sys, time, threading, signal
try:
    import RPi.GPIO
except ImportError:
    sys.stderr.write("ERROR: RPi.GPIO not installed. Install with: sudo apt install -y python3-rpi.gpio\n")
    raise

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

# BOARD numbers (physical header pins)
POWER_SWITCH_PIN = 5   # power switch input   (GPIO3)
RESET_SWITCH_PIN = 3   # reset switch input   (GPIO2)
POWER_PIN = 7          # power enable output  (GPIO4)
LED_PIN = 8            # LED enable output    (GPIO14)
POLL_INTERVAL = 0.1

SWITCH_COMMAND_MAP = {
    POWER_SWITCH_PIN: os.path.join(SCRIPT_DIR, 'shutdown.retropie') + ' power',
    RESET_SWITCH_PIN: os.path.join(SCRIPT_DIR, 'shutdown.retropie') + ' reset',
}

def main():
    init_gpio()
    led_blinker = Blinker(LED_PIN); led_blinker.start()

    def handle_signal(signum, frame):
        led_blinker.stop(); led_blinker.join(); sys.exit(0)
    signal.signal(signal.SIGINT, handle_signal)
    signal.signal(signal.SIGTERM, handle_signal)

    while True:
        pin = wait_for_press([POWER_SWITCH_PIN, RESET_SWITCH_PIN])
        led_blinker.blink()
        os.system(SWITCH_COMMAND_MAP[pin])
        led_blinker.solid()

def init_gpio():
    RPi.GPIO.setmode(RPi.GPIO.BOARD)
    RPi.GPIO.setwarnings(False)
    RPi.GPIO.setup(POWER_SWITCH_PIN, RPi.GPIO.IN, pull_up_down=RPi.GPIO.PUD_UP)
    RPi.GPIO.setup(RESET_SWITCH_PIN, RPi.GPIO.IN, pull_up_down=RPi.GPIO.PUD_UP)
    RPi.GPIO.setup(POWER_PIN, RPi.GPIO.OUT, initial=RPi.GPIO.HIGH)

def wait_for_press(pins):
    prev = [RPi.GPIO.input(p) for p in pins]
    while True:
        cur = []
        for i,p in enumerate(pins):
            s = RPi.GPIO.input(p)
            if prev[i] == RPi.GPIO.HIGH and s == RPi.GPIO.LOW:
                return p
            cur.append(s)
        prev = cur
        time.sleep(POLL_INTERVAL)

class Blinker(threading.Thread):
    DEFAULT_STATE = True
    BLINK_INTERVAL = 0.25
    def __init__(self, pin):
        super().__init__()
        self._pin = pin
        self._blink = threading.Event()
        self._stop = threading.Event()
        RPi.GPIO.setup(pin, RPi.GPIO.OUT)
    def run(self):
        state = self.DEFAULT_STATE
        while not self._stop.is_set():
            if self._blink.is_set():
                state = not state
            else:
                state = self.DEFAULT_STATE
            RPi.GPIO.output(self._pin, state)
            self._stop.wait(self.BLINK_INTERVAL)
        RPi.GPIO.output(self._pin, self.DEFAULT_STATE)
    def stop(self): self._stop.set()
    def blink(self): self._blink.set()
    def solid(self): self._blink.clear()

if __name__ == '__main__':
    main()
